let login;
let register;
let upperbg;
let loginform;
let registerform;

login=document.getElementById("btn_1");
register=document.getElementById("btn_2");
upperbg=document.getElementById("bgcolor");
loginform=document.querySelector(".login");
registerform=document.querySelector('.register_hidden')

register.onclick=function(){
    upperbg.style.left="49%";
    loginform.classList.add("hide");
    registerform.classList.remove("hide");
}

login.onclick=function(){
    upperbg.style.left="0"
    loginform.classList.remove("hide");
    registerform.classList.add("hide");
}