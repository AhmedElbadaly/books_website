const slider = document.querySelector('.slider');
const slides = document.querySelectorAll('.slide');
let currentIndex = 0;

function goToSlide(index) {
        slides[currentIndex].classList.remove('active');
        currentIndex = index;
        slides[currentIndex].classList.add('active');
}

function prevSlide() {
        const newIndex = (currentIndex - 1 + slides.length) % slides.length;
        goToSlide(newIndex);
}

function nextSlide() {
    const newIndex = (currentIndex + 1) % slides.length;
    goToSlide(newIndex);
    }

function startSlider() {
    slides[currentIndex].classList.add('active');
    setInterval(nextSlide, 3000);
}

startSlider();

document.getElementById("lnx").addEventListener('click', function() {
    swtch('Linux_page.html');
});

document.getElementById("alg").addEventListener('click', function() {
    swtch('Grookingalgorithm_page.html');
});

document.getElementById("hndbok").addEventListener('click', function() {
    swtch('webapp_page.html');
});

document.getElementById("dumnet").addEventListener('click', function() {
    swtch('net4dum_page.html');
});

document.getElementById("pyo").addEventListener('click', function() {
    swtch('Thinkpy_page.html');
});

document.getElementById("clncod").addEventListener('click', function() {
    swtch('Cleancode_page.html');
});

document.getElementById("blkhat").addEventListener('click', function() {
    swtch('Blackhat_page.html');
});

document.getElementById("hdfrst").addEventListener('click', function() {
    swtch('DesignPattern_page.html');
});

function swtch(page) {
    window.location.href = page;
}