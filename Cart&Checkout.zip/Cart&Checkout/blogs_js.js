function publish() {
    if (document.getElementById("bookentry").value != "" && document.getElementById("message").value != ""){
        Swal.fire({
            icon: 'success',
            title: 'Success',
            title: 'your review has been sent',
        })
    }
    else{
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'All fields are required',
        })
    }
}
function reset() {
    document.getElementById("bookentry").value = ""
    document.getElementById("message").value = ""
}