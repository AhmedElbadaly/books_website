const cartIcon = document.getElementById("cart-icon");
const cartDiv = document.getElementById("cart-div");

cartIcon.addEventListener("click", () => {
  cartDiv.classList.toggle("hidden");
});
// Add your JavaScript code for adding/removing items, updating price, etc.
const addToCart = document.querySelectorAll('.Add-To-Cart');

addToCart.forEach(button => {
  button.addEventListener('click', function() {
    const productImage = this.parentNode;
    const productName = productImage.dataset.productName;
    const productPrice = productImage.dataset.productPrice;

    const cartItems = document.getElementById('cart-items');
    const newCartItem = document.createElement('div');
    newCartItem.classList.add('cart-item');
    newCartItem.innerHTML = `
      <p>${productName}</p>
      <span>$${productPrice}</span>
      <button class="remove-item">Remove</button>
    `;

    cartItems.appendChild(newCartItem);

    updateTotalPrice(); // Function to update total price in cart

    // Display "empty cart message" if hidden
    const emptyMessage = document.getElementById('empty-cart-message');
    if (emptyMessage.classList.contains('hidden')) {
      emptyMessage.classList.add('hidden');
    }
  });
});

function updateTotalPrice() {
  // Calculate and update total price in cart using the cart items
  const totalPriceEl = document.getElementById('total-price');
  let totalPrice = 0;
  // ... logic to calculate total price based on cart items ...
  totalPriceEl.innerText = totalPrice;
}
const removeItemButtons = document.querySelectorAll('.remove-item');

removeItemButtons.forEach(button => {
  button.addEventListener('click', function() {
    const cartItem = this.parentNode;
    cartItems.removeChild(cartItem);
    updateTotalPrice(); // update total price after removing item
  });
});
const quantityInputs = document.querySelectorAll('.cart-item input');

quantityInputs.forEach(input => {
  input.addEventListener('change', function() {
    const newQuantity = parseInt(this.value);
    const priceEl = this.parentNode.querySelector('span');
    const price = parseInt(priceEl.innerText.substring(1));
    priceEl.innerText = `$${newQuantity * price}`;
    updateTotalPrice();
  });
});
